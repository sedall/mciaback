<?php

return [
    'name' => 'Auth',
];
