<?php

return [
    'name' => 'Customers',
];
