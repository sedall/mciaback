<?php

return [
    'name' => 'CustomerDocuments',
];
