<?php

return [
    'name' => 'Loans',
];
