<?php

return [
    'name' => 'Clinics',
];
