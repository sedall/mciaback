<?php

return [
    'name' => 'Tickets',
];
