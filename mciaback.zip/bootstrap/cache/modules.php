<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Access\\Providers\\AccessServiceProvider',
    1 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    2 => 'Modules\\Clinics\\Providers\\ClinicsServiceProvider',
    3 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    4 => 'Modules\\CustomerDocuments\\Providers\\CustomerDocumentsServiceProvider',
    5 => 'Modules\\Customers\\Providers\\CustomersServiceProvider',
    6 => 'Modules\\IAM\\Providers\\IAMServiceProvider',
    7 => 'Modules\\Loans\\Providers\\LoansServiceProvider',
    8 => 'Modules\\Loans\\Providers\\RouteServiceProvider',
    9 => 'Modules\\Loans\\Providers\\EventServiceProvider',
    10 => 'Modules\\Settings\\Providers\\SettingsServiceProvider',
    11 => 'Modules\\Settings\\Providers\\RouteServiceProvider',
    12 => 'Modules\\Tickets\\Providers\\TicketsServiceProvider',
    13 => 'Modules\\Tickets\\Providers\\RouteServiceProvider',
    14 => 'Modules\\Tickets\\Providers\\EventServiceProvider',
    15 => 'Modules\\Users\\Providers\\UsersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Access\\Providers\\AccessServiceProvider',
    1 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    2 => 'Modules\\Clinics\\Providers\\ClinicsServiceProvider',
    3 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    4 => 'Modules\\CustomerDocuments\\Providers\\CustomerDocumentsServiceProvider',
    5 => 'Modules\\Customers\\Providers\\CustomersServiceProvider',
    6 => 'Modules\\IAM\\Providers\\IAMServiceProvider',
    7 => 'Modules\\Loans\\Providers\\LoansServiceProvider',
    8 => 'Modules\\Loans\\Providers\\RouteServiceProvider',
    9 => 'Modules\\Loans\\Providers\\EventServiceProvider',
    10 => 'Modules\\Settings\\Providers\\SettingsServiceProvider',
    11 => 'Modules\\Settings\\Providers\\RouteServiceProvider',
    12 => 'Modules\\Tickets\\Providers\\TicketsServiceProvider',
    13 => 'Modules\\Tickets\\Providers\\RouteServiceProvider',
    14 => 'Modules\\Tickets\\Providers\\EventServiceProvider',
    15 => 'Modules\\Users\\Providers\\UsersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);